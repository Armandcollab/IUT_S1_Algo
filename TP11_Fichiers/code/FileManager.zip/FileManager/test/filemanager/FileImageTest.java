package filemanager;

import org.junit.Test;

/**
 * Tests unitaires de la classe FileImage.
 */
public class FileImageTest {
    
    @Test
    public void MergeImageFileWithMissingParts() {
        FileImage.mergeImageFileWithMissingParts();
    }
}
