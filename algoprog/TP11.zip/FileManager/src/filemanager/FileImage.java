package filemanager;

/**
 * TP fichiers : image à reconstituer.
 */
public class FileImage {

    /**
     * Utiliser les imagettes pour former l'image complète.
     */
    static void mergeImageFileWithMissingParts() {
        //Taille image avec partie manquante : 200 84
        //11 imagettes 200 6
        //L'image fusionnée 200 150
        //48 ème ligne
        
    }
}
