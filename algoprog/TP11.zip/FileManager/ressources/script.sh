#!/bin/bash
chmod ugo-r dont1.txt
chmod ugo-w write2/citation2.txt
