package distributeurfriandise;

import org.junit.Test;

/**
 * Tests unitaires de la classe Distributeur.
 */
public class DistributeurTest {
    
    @Test
    public void testAjouterBonbon() {
    }

    @Test
    public void testRetirerBonbon() {
    }

    @Test
    public void testRetirerBonbons_int() {
    }

    @Test
    public void testRetirerBonbons_0args() {
    }

    @Test
    public void testPlein() {
    }

    @Test
    public void testVide() {
    }

    @Test
    public void testNombreBonbons() {
    }

}
