package distributeurfriandise;

import org.junit.Test;

/**
 * Tests unitaires de la classe Bonbon.
 */
public class BonbonTest {
    
    @Test
    public void testChewingGum() {
    }

    @Test
    public void testChypresers() {
    }

    @Test
    public void testTigre() {
    }

    @Test
    public void testNoisettes() {
    }

    @Test
    public void testVenus() {
    }

}
